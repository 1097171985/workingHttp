//
//  XWAfnGlobeConst.h
//  XWNetworking
//
//  Created by xinwang2 on 2018/1/24.
//  Copyright © 2018年 xinwang2. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XWAfnGlobeConst : NSObject

extern const NSString *XWNetworkingHeaderUuid;

extern const NSString *XWNetworkingHeaderToken;

extern const NSString *XWNetworkingHeaderUserAgent;
@end
