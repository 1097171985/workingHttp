//
//  XWAfnGlobeConst.m
//  XWNetworking
//
//  Created by xinwang2 on 2018/1/24.
//  Copyright © 2018年 xinwang2. All rights reserved.
//

#import "XWAfnGlobeConst.h"

@implementation XWAfnGlobeConst

const NSString *XWNetworkingHeaderUuid  = @"请设置UUID";

const NSString *XWNetworkingHeaderToken = @"请设置token";

const NSString *XWNetworkingHeaderUserAgent = @"请设置userAgent";

@end
